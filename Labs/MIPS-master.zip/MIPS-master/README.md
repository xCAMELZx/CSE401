##MIPS pipeline datapath for CSE 401 Computer Architecture

A program written in Verilog that simulates the MIPS architecture. The original source code was incomplete and was modified extensively to work. The missing modules and written code was completed using the design/diagrams outlined in the lab manual. The program executes the assembly language instruction written in binary code contained in a text file and outputs the result.
The instruction is located in /etc/RISC.txt that adds the numbers (1+2)+3+6+0=12.

[Lab Manual](http://www.cse.csusb.edu/egomez/cs401/manual/Georgiou-verilog.pdf)

Timing diagram:
![Alt text](http://img.photobucket.com/albums/v35/seiji_keisuke/git/timing_diagram_zps8nrnbrze.png "Screenshot in Xilinx ISE Design Suite")
